#include <opencv2/opencv.hpp>
#include <stdio.h>  
#include <sys/stat.h>  
#include <sys/types.h>  
#include <time.h>  
#include <sys/timeb.h>  
#include <stdlib.h>  
#include <cv.h>  
#include <cxcore.h>  
#include <highgui.h>
#include "/root/Codes/robot/arm/photo/include/binary.h"
#include "/root/Codes/robot/arm/photo/include/deonising.h"
#include "/root/Codes/robot/arm/photo/include/edge.h"
using namespace std;


IplImage *g_pGrayImage = NULL;
IplImage *g_pBinaryImage = NULL;
const char *pstrWindowsBinaryTitle = "二值图(http://blog.csdn.net/MoreWindows)";


void on_trackbar(int pos)
{
	// 转为二值图
  //cvThreshold 对单通道数组应用固定阈值操作。该函数的典型应用是对灰度图像进行阈值操作得到二值图像
	cvThreshold(g_pGrayImage, g_pBinaryImage, pos, 255, CV_THRESH_BINARY);
	// 显示二值图
	// cvShowImage(pstrWindowsBinaryTitle, g_pBinaryImage);
  cvShowImage(pstrWindowsBinaryTitle, g_pGrayImage);
}

int main( int argc, char** argv )
{	
	const char *pstrWindowsSrcTitle = "原图";  
	const char *pstrWindowsToolBarName = "二值图阈值";
  	binary photo;

  	// take photo
	photo.take_photo();
	// read picture which taken by take_photo()
	IplImage *SrcImg = cvLoadImage("/root/for_test/SrcImg.jpg", CV_LOAD_IMAGE_UNCHANGED);
	// turn to gray image
	IplImage* GrayImg =  cvCreateImage(cvGetSize(SrcImg), IPL_DEPTH_8U, 1);
	cvCvtColor(SrcImg, GrayImg, CV_BGR2GRAY);
  	// turn to binary image
	IplImage* BinaImg = photo.GetPos(GrayImg);
  	
  	//desimosing
  	struct Point elem;
  	int i,j;
  	IplImage* DeonImg;
	Deonising deonising(BinaImg);
	cout<<"height:"<<deonising._height<<"   "<<"width:"<<deonising._width<<endl;
	for(int m=0; m<5; m++)
	{
		for(i=0; i<deonising._height; i++)
		{
			for(j=0; j<deonising._width; j++)	
			{
				elem.x = j;
				elem.y = i;
				deonising.extract_point(elem);
			}	
		}
		DeonImg = deonising.smooth();
	}
	cout<<"deonising over......"<<endl;
	deonising.show();

	//find edge
	Edge edge(DeonImg);
	edge.sweep();
	edge.paint();
	edge.sweep();
	edge.paint();
	edge.sweep();
	edge.paint();
	edge.sweep();
	edge.paint();
	edge.sweep();
	edge.paint();
	edge.sweep();
	edge.paint();
	edge.sweep();
	edge.paint();
	edge.sweep();
	edge.paint();

	return 0;
}
