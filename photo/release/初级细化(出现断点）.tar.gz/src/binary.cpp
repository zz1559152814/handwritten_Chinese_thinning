#include <opencv2/opencv.hpp>
// #include "take_photo.h"
#include <stdio.h>  
#include <sys/stat.h>  
#include <sys/types.h>  
#include <time.h>  
#include <sys/timeb.h>  
#include <stdlib.h>  
#include <cv.h>  
#include <cxcore.h>  
#include <highgui.h>
#include "/root/Codes/robot/arm/photo/include/binary.h"
using namespace std;


int binary::take_photo()  
{  
    //声明IplImage指针  
    IplImage* pFrame=NULL;  
    IplImage* pSaveFrame=NULL;  
    CvCapture* pCapture=NULL;  
    static char filename[100];  
    struct tm * tm_ptr;  
    struct timeb tp;  
    int p[3];  
    p[0] = CV_IMWRITE_JPEG_QUALITY;  
    p[1] = 100;  //质量值  
    p[2] = 0;  
    //创建窗口  
    cvNamedWindow("video",1);  
    //打开摄像头  
    if( !(pCapture=cvCaptureFromCAM(-1)) ) //此处值为-1表示自动搜索到的第一个摄象头，而0则表示第一个，1则表示第2个，以此类推。  
    {  
        fprintf(stderr,"Can not open camera.\n");  
        return -1;  
    }    
    if(mkdir("/root/for_test",0755)==-1)  
    {  
      //创建时存在该目录会返回错误码，如不存在则创建它，但由于我们需要该目录，则出错也不处理  
    }  
    //逐帧读取视频  
    while(pFrame=cvQueryFrame(pCapture))  
    {  
      cvShowImage("video",pFrame);  
      if(cvWaitKey(2)>=0) break;  
      pSaveFrame=cvCreateImage(cvSize(640,480),pFrame->depth,pFrame->nChannels);  
      //get file name  
      ftime(&tp);  
      tm_ptr=localtime(&tp.time);  
      snprintf(filename, 40, "/root/for_test/SrcImg.jpg",tm_ptr->tm_year-100+2000,    tm_ptr->tm_mon + 1, tm_ptr->tm_mday, tm_ptr->tm_hour,tm_ptr->tm_min, tm_ptr->tm_sec,tp.millitm);  
      cvResize(pFrame,pSaveFrame,CV_INTER_LINEAR);  
      cvSaveImage(filename,pSaveFrame,p);  
      cvReleaseImage(&pSaveFrame);  
    }  
    cvDestroyWindow("video");  
    cvReleaseCapture(&pCapture);  
    return 0;  
}  

IplImage* binary::Histogram(IplImage * gray_dst)  
{  
  // IplImage* src= cvLoadImage("F:\\Opencv_picture\\05.jpg");
  // IplImage* gray_dst= cvCreateImage(cvGetSize(src), 8, 1);
  // cvCvtColor(src, gray_dst, CV_BGR2GRAY);

  //一维维数
  int dims= 1;
  //直方图的尺寸
  int size= 256;
  //直方图的高度
  int height = 256;
  //灰度图的范围0到255
  float range[]= {0, 256};
  float *ranges[]= {range}; 
    
  //创建一维直方图
  CvHistogram* hist;
  hist= cvCreateHist(dims, &size, CV_HIST_ARRAY, ranges, 1);      

  //计算灰度图的一维直方图
  cvCalcHist(&gray_dst, hist, 0, 0);
    //归一化直方图
  cvNormalizeHist(hist, 1.0);
  int scale= 2;
  //创建图像，用于显示直方图
  IplImage* hist_img= cvCreateImage(cvSize(size* scale, height), 8, 1);
  //图像置零
  cvZero(hist_img);

  //计算直方图的最大方块值,初始化为0
  float max_value= 0;
  cvGetMinMaxHistValue(hist, 0, &max_value, 0, 0);

   //绘制直方图
  for(int i=0; i<size; i++)
  {
    float bin_val= cvQueryHistValue_1D(hist,i);   //像素i的概率
    int intensity = cvRound(bin_val* height/ max_value);  // 绘制的高度
    cvRectangle(hist_img,
                cvPoint(i* scale, height- 1),
                cvPoint((i+1)* scale- 1, height- intensity),
                CV_RGB(255, 255, 255));
   }

  cvNamedWindow("Histogram");
  cvShowImage("Histogram", hist_img);
  cvSaveImage("/root/for_test/HistImg.jpg",hist_img,0);
  cvWaitKey(0);

  // cvReleaseImage(&src);
  cvReleaseImage(&gray_dst);
  cvReleaseImage(&hist_img);

  cvDestroyWindow("gray");
  cvDestroyWindow("Histogram");

  return 0;
}

IplImage* binary::GetPos(IplImage* gray_dst) 
{
  uchar ImgData;
  // get the cout of index 
  int grayvalue[256] = {0};
  for(int i = 0; i < gray_dst->height; i++)
  {
    for(int j = 0; j < gray_dst->width; j++) 
    {
      ImgData = gray_dst->imageData[i*gray_dst->height+j];
      grayvalue[(int)ImgData] += 1;
    }
  }
  int pro_mean,temp_pro_mean; // probility mean value
  int open = 1;               // skip pix high which value is low
  int min_n;                  // record the index of the min_pos
  for(int n = 255; n-3 > 20; n--)
  {
    pro_mean = grayvalue[n] + grayvalue[n-1] + grayvalue[n-2];
    pro_mean /= 3;

    if(open = 1)
    {
      if(pro_mean >= 1000)
      {
        open = 0;
        min_n = n;
      }
    }
    else
    {
      if(pro_mean <= temp_pro_mean)
      {
        min_n = n;
      }
    }
    temp_pro_mean = pro_mean;
  }
  cout<<"the best threshold is "<<min_n;

  IplImage *g_pBinaryImage = NULL;
  const char *pstrWindowsBinaryTitle = "二值图";
  // creat image
  g_pBinaryImage = cvCreateImage(cvGetSize(gray_dst), IPL_DEPTH_8U, 1);
  // 对单通道数组应用固定阈值操作。该函数的典型应用是对灰度图像进行阈值操作得到二值图像
  cvThreshold(gray_dst, g_pBinaryImage, min_n - 25, 255, CV_THRESH_BINARY);
  cvShowImage(pstrWindowsBinaryTitle, g_pBinaryImage);
  cvWaitKey(0);
  cvSaveImage("/root/for_test/BinaImg.jpg",g_pBinaryImage,0);
  cvReleaseImage(&gray_dst);
  return g_pBinaryImage;
} 


