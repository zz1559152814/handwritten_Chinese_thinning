#ifndef A_H__
#define A_H__

class binary
{
public:
	int take_photo(); 
	IplImage* Histogram(IplImage * src);
	IplImage* GetPos(IplImage* gray_dst);
};
#endif