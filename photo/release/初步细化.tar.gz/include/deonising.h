#ifndef THIN_H__
#define THIN_H__
#include <vector>

struct Point 
{
	int x;
	int y;
};
class Deonising
{
public:
	Deonising(IplImage* Img);
	int extract_point(struct Point elem);
	IplImage* smooth(void);
	int show(void);
	int _width;
	int _height;
	int update(IplImage* Img);

private:
	IplImage* _src;
};

extern std::vector<struct Point> b_to_w;
extern std::vector<struct Point> w_to_b;
#endif