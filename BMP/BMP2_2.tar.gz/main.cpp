// #include "stdafx.h"   
#include "bmp.h"   
#include <stdio.h>
#include <memory.h>
#include <stdlib.h>




int main()  
{  
    // ClImage* img = clLoadImage("/home/dream/out2.bmp");  
    ClImage img;
    img.channels = 1;
    img.width = 122;
    img.height = 122;
    int w,h;
    // img->imageData = (unsigned char*)malloc(sizeof(char)*20*20);  
    img.imageData = (unsigned char*)malloc(sizeof(unsigned char)*img.width*img.height);  
    for(h=img.height-1; h>-1; h--)
    {
        for(w = 0; w < img.width-1; w++)   
        {
            img.imageData[h*img.width + w] = 255;
        }
    }
    bool flag = clSaveImage("/home/dream/resul1.bmp", &img);
    if(flag)  
    {  
        printf("save ok... \n");  
    }  
    while(1);  
    return 0;  
}  
